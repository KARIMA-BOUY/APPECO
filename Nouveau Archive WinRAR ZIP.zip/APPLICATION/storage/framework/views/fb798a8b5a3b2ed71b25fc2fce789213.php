
<?php $__env->startSection('contenu'); ?>
    <h3>UPDATE PRODUCT</h3>

    <?php if($errors->any()): ?>
        <h6>Errors :</h6>
        <ul> 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <form action="<?php echo e(route('products.update',$product)); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $product->name)); ?>">
            <?php $__errorArgs = ['poduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label class="form-label">description</label>
            <input type="text" name="description" class="form-control" value="<?php echo e(old('description', $product->description)); ?>">
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label class="form-label">quantite</label>
            <input type="text" name="quantite" class="form-control" value="<?php echo e(old('quantite', $product->quantite)); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">image</label>
            <input type="file" name="image" class="form-control" value="<?php echo e(old('image', $product->image)); ?>">
        </div>
        <div class="mb-3">
            <label class="form-label">price</label>
            <input type="number" name="price" class="form-control" value="<?php echo e(old('price', $product->price)); ?>">
        </div>
        <button type="submit" class="btn btn-success">Modifier Product</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/product/edit.blade.php ENDPATH**/ ?>