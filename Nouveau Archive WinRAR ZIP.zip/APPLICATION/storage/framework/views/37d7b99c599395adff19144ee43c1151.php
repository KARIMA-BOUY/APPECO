<!DOCTYPE html>
<html>
<head>
    <title>Authors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<?php $__env->startSection('contenu'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h1 class="w-100 text-center">Authors</h1>
    <a href="<?php echo e(route('auteur.create')); ?>" class="btn btn-primary">Create</a>
</div>

<table class="table container">
    <thead>
        <tr>
            <th>ID</th>
            <th>Author Name</th>
            <th>Actions</th>   
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($author->id); ?></td>
            <td><a href="<?php echo e(route('auteur.show', $author->id)); ?>"><?php echo e($author->author_name); ?></a></td>
            <td class="d-flex">
            <a href="<?php echo e(route('auteur.edit',$author)); ?>" class="btn btn-primary me-1">Update</a>
            <a href="<?php echo e(route('auteur.show',$author->id)); ?>" class="btn btn-success me-1">Show</a>
                <form method="POST" action="<?php echo e(route('auteur.destroy', $author)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <input type="submit" class="btn btn-danger" value="Delete">
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="d-flex justify-content-center mt-3">
    <?php echo e($authors->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php echo $__env->make('ayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/index.blade.php ENDPATH**/ ?>