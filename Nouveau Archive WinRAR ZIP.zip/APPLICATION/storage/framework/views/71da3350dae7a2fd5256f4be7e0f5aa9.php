
<?php $__env->startSection('contenu'); ?>

<div class="d-flex justify-content-between align-items-center">
<h1> PRODUCT LIST</h1>
<a href="<?php echo e(route('products.create')); ?>" class="btn btn-prmary">create</a>
</div>
<table class="container">
    <thead>
        <tr>
            <th>id</th>
            <th>name</th>
            <th>description</th>
            <th>image</th>
            <th>Quantite</th>
            <th>Actions</th>   
        </tr>
</thead>
 <?php $__currentLoopData = $produit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <tr> 
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->description); ?></td>
            <td><?php echo e($product->image); ?></td>
            <td><?php echo e($product->Quantite); ?></td>
            <td><?php echo e($product->Actions); ?></td>   
            <td><div  class="btn-group">
        <a href="<?php echo e(route('products.edit',$product)); ?>" class="btn btn-primary">Update</a>
        <form method="post" action="<?php echo e(route('products.destroy',$product)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <input type="submit" class="btn btn-danger" value="delete"></td></div>
</tr>

  
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('ayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/Product/index.blade.php ENDPATH**/ ?>