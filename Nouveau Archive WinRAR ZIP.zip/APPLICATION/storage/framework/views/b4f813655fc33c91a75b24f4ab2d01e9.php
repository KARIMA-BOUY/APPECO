<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($authors->authors_name); ?></title>
</head>
<body>
    <h1><?php echo e($authors->authors_name); ?></h1>
    <p><?php echo e($authors->biography->bio); ?></p>
    <h2>Books</h2>
    <ul>
        <?php $__currentLoopData = $authors->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($book->book_title); ?> - Genres:
                <ul>
                    <?php $__currentLoopData = $book->genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($genre->genre_name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <a href="<?php echo e(route('auteur.index')); ?>">Back to Authors</a>
</body>
</html>
<?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/show.blade.php ENDPATH**/ ?>