<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> -->
    <link rel="stylesheet" href= "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title></title>
</head>
<body>
    
    <div>
        <?php echo $__env->yieldContent('contenu'); ?>
</div>
<!-- <div class="container">
    <?php if($errors->any()): ?>
     <div class="alert alert-danger" role="alert">
        <strong>Erros</strong>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $errors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li> <?php echo e($errors); ?> </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
</dev>
<?php endif; ?>
<?php echo $__env->yieldContent('contenu'); ?> -->
</div>
</body>
</html><?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/ayouts/app.blade.php ENDPATH**/ ?>