
<?php $__env->startSection('contenu'); ?>
    <h3 class="text-center">Ajouter PRODUCT</h3>
    <?php if($errors->any()): ?>
        <h6>Errors :</h6>
        <ul> 
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
    <div class="container w-50" >
    <form action="<?php echo e(route('products.store')); ?>" method="POST" >
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">name</label>
            <input type="text" name="name" class="form-control">
            <?php $__errorArgs = ['poduct'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label class="form-label">description</label>
            <input type="text" name="description" class="form-control" >
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="mb-3">
            <label class="form-label">quantite</label>
            <input type="text" name="quantity" class="form-control" >
        </div>
        <div class="mb-3">
            <label class="form-label">image</label>
            <input type="file" name="image" class="form-control">
        </div>
        <div class="mb-3">
            <label class="form-label">price</label>
            <input type="number" name="price" class="form-control">
        </div>
        <button type="submit" class="btn btn-success">Ajouter Product</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ayouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\APPECO\APPLICATION\resources\views/product/create.blade.php ENDPATH**/ ?>