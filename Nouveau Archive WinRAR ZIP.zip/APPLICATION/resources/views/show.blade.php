<!DOCTYPE html>
<html>
<head>
    <title>{{ $authors->authors_name }}</title>
</head>
<body>
    <h1>{{ $authors->authors_name }}</h1>
    <p>{{ $authors->biography->bio }}</p>
    <h2>Books</h2>
    <ul>
        @foreach($authors->books as $book)
            <li>{{ $book->book_title }} - Genres:
                <ul>
                    @foreach($book->genres as $genre)
                        <li>{{ $genre->genre_name }}</li>
                    @endforeach
                </ul>
            </li>
        @endforeach
    </ul>
    <a href="{{ route('auteur.index') }}">Back to Authors</a>
</body>
</html>
